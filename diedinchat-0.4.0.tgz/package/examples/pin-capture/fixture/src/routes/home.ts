export const home = () => "home";
